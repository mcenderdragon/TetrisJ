/*     */ package dragon.tetris;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TetrisFrame
/*     */   extends Frame
/*     */ {
/*     */   private static final long serialVersionUID = 2799508602273231127L;
/*     */   public static final int KEY_UP = 38;
/*     */   public static final int KEY_DOWN = 40;
/*     */   public static final int KEY_LEFT = 37;
/*     */   public static final int KEY_RIGHT = 39;
/*     */   public final int blockSize;
/*     */   public Color[][] grid;
/*     */   
/*     */   public TetrisFrame(final GameControler control)
/*     */   {
/*  33 */     super("Tetris");
/*     */     
/*  35 */     this.grid = new Color[control.screenW][control.screenH];
/*  36 */     setSize(375, 500);
/*  37 */     this.blockSize = (500 / control.screenH);
/*     */     
/*  39 */     addKeyListener(new KeyListener()
/*     */     {
/*     */       public void keyTyped(KeyEvent e) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       public void keyReleased(KeyEvent e) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void keyPressed(KeyEvent e)
/*     */       {
/*  52 */         if (Main.remote) {
/*  53 */           return;
/*     */         }
/*  55 */         switch (e.getKeyCode())
/*     */         {
/*     */         case 38: 
/*  58 */           Main.logger.onKeyPressed(Main.Keys.UP);
/*  59 */           control.rotate();
/*  60 */           break;
/*     */         case 37: 
/*  62 */           Main.logger.onKeyPressed(Main.Keys.LEFT);
/*  63 */           control.shiftLeft();
/*  64 */           break;
/*     */         case 39: 
/*  66 */           Main.logger.onKeyPressed(Main.Keys.RIGHT);
/*  67 */           control.shiftRight();
/*  68 */           break;
/*     */         case 40: 
/*  70 */           Main.logger.onKeyPressed(Main.Keys.LEFT);
/*  71 */           control.putDown();
/*  72 */           break;
/*     */         
/*     */         }
/*     */         
/*     */       }
/*  77 */     });
/*  78 */     addWindowListener(new WindowListener()
/*     */     {
/*     */       public void windowOpened(WindowEvent paramWindowEvent) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowIconified(WindowEvent paramWindowEvent) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowDeiconified(WindowEvent paramWindowEvent) {}
/*     */       
/*     */ 
/*     */       public void windowDeactivated(WindowEvent paramWindowEvent) {}
/*     */       
/*     */ 
/*     */       public void windowClosing(WindowEvent paramWindowEvent)
/*     */       {
/*  96 */         Main.run = false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowClosed(WindowEvent paramWindowEvent) {}
/*     */       
/*     */ 
/*     */       public void windowActivated(WindowEvent paramWindowEvent) {}
/* 105 */     });
/* 106 */     setResizable(false);
/* 107 */     setVisible(true);
/*     */   }
/*     */   
/* 110 */   private int lastScore = -1;
/*     */   
/*     */   public void render()
/*     */   {
/* 114 */     Graphics graph = getGraphics();
/*     */     
/* 116 */     for (int x = 0; x < this.grid.length; x++)
/*     */     {
/* 118 */       for (int y = 0; y < this.grid[x].length; y++)
/*     */       {
/* 120 */         if (this.grid[x][y] == null)
/*     */         {
/* 122 */           graph.setColor(Color.LIGHT_GRAY);
/* 123 */           graph.fillRect(5 + this.blockSize * x, 5 + this.blockSize * y, this.blockSize, this.blockSize);
/*     */         }
/*     */         else
/*     */         {
/* 127 */           graph.setColor(Color.BLACK);
/* 128 */           graph.fillRect(5 + this.blockSize * x, 5 + this.blockSize * y, this.blockSize, this.blockSize);
/* 129 */           graph.setColor(this.grid[x][y]);
/* 130 */           graph.fillRect(5 + this.blockSize * x + 1, 5 + this.blockSize * y + 1, this.blockSize - 2, this.blockSize - 2);
/*     */         }
/*     */       }
/*     */     }
/* 134 */     if (Main.score != this.lastScore)
/*     */     {
/* 136 */       graph.setColor(Color.WHITE);
/* 137 */       graph.fillRect(this.blockSize * 11, this.blockSize * 4, this.blockSize * 5, this.blockSize * 2);
/* 138 */       graph.setColor(Color.BLACK);
/* 139 */       graph.drawString("Score: " + Main.score, this.blockSize * 12, this.blockSize * 5);
/* 140 */       this.lastScore = Main.score;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Tüp\Desktop\tetrs ai\TetrisJ v5.1.jar!\dragon\tetris\TetrisFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */