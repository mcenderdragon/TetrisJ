/*     */ package dragon.tetris;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogGenerator
/*     */ {
/*     */   private OutputStream out;
/*  15 */   private int rotation = 0;
/*     */   private StringBuilder builder;
/*     */   
/*     */   public LogGenerator() throws FileNotFoundException, IOException {
/*  19 */     this.out = new GZIPOutputStream(new FileOutputStream("./teris_" + System.currentTimeMillis() / 1000L + ".t7"));
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*  24 */     this.out.close();
/*     */   }
/*     */   
/*     */   public void onKeyPressed(Main.Keys key)
/*     */   {
/*  29 */     if (key == Main.Keys.UP)
/*     */     {
/*  31 */       this.rotation += 1;
/*  32 */       this.rotation %= 4;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private String currentState(int[][] data)
/*     */   {
/*  39 */     String s = "";
/*  40 */     for (int y = 0; y < Main.con.screenH; y++)
/*     */     {
/*  42 */       for (int x = 0; x < Main.con.screenW; x++)
/*     */       {
/*  44 */         s = s + Math.min(1, data[x][y]);
/*     */       }
/*     */     }
/*  47 */     return s;
/*     */   }
/*     */   
/*     */   private String currentShape(boolean[][] aktiveBlock)
/*     */   {
/*  52 */     String s = "";
/*  53 */     for (int x = 0; x < 4; x++)
/*     */     {
/*  55 */       for (int y = 0; y < 4; y++)
/*     */       {
/*  57 */         if (x < aktiveBlock.length)
/*     */         {
/*  59 */           if (y < aktiveBlock[x].length)
/*     */           {
/*  61 */             s = s + (aktiveBlock[x][y] != 0 ? '1' : '0');
/*     */           }
/*     */           else
/*     */           {
/*  65 */             s = s + '0';
/*     */           }
/*     */           
/*     */         }
/*     */         else {
/*  70 */           s = s + '0';
/*     */         }
/*     */       }
/*     */     }
/*  74 */     return s;
/*     */   }
/*     */   
/*     */   public void onNewShape(int[][] finishedGrid, boolean[][] aktiveBlock)
/*     */   {
/*  79 */     if (this.builder != null)
/*     */     {
/*  81 */       this.builder.append(";;\n");
/*     */       try
/*     */       {
/*  84 */         this.out.write(this.builder.toString().getBytes());
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*  88 */         e.printStackTrace();
/*     */       }
/*     */     }
/*  91 */     this.builder = new StringBuilder();
/*  92 */     this.rotation = 0;
/*  93 */     this.builder.append(currentState(finishedGrid));
/*  94 */     this.builder.append(';');
/*  95 */     this.builder.append(currentShape(aktiveBlock));
/*     */   }
/*     */   
/*     */   public void shapeCollided(int xPos, int yPos)
/*     */   {
/* 100 */     this.builder.append("=" + xPos + ";" + yPos + ";" + this.rotation);
/*     */   }
/*     */   
/*     */   public void onRemoveLine()
/*     */   {
/* 105 */     if (this.builder != null)
/*     */     {
/* 107 */       this.builder.append('\n');
/*     */       try
/*     */       {
/* 110 */         this.out.write(this.builder.toString().getBytes());
/* 111 */         this.out.flush();
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 115 */         e.printStackTrace();
/*     */       }
/* 117 */       this.builder = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getStatus()
/*     */   {
/* 123 */     return this.builder == null ? null : this.builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Tüp\Desktop\tetrs ai\TetrisJ v5.1.jar!\dragon\tetris\LogGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */