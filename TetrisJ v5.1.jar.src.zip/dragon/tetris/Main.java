/*    */ package dragon.tetris;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class Main
/*    */ {
/*    */   public static TetrisFrame frame;
/*    */   public static GameControler con;
/* 10 */   public static int score = 0;
/*    */   
/*    */   public static LogGenerator logger;
/*    */   
/*    */   public static AIConnection aiServer;
/* 15 */   public static boolean run = true;
/* 16 */   public static boolean remote = false;
/*    */   
/* 18 */   public static boolean doTick = true;
/*    */   
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 24 */       con = new GameControler(10, 30, 5);
/* 25 */       con.addShape(new boolean[][] { { true, true, true, true } });
/* 26 */       con.addShape(new boolean[][] { { true, true }, { true, true } });
/* 27 */       con.addShape(new boolean[][] { { true }, { true, true, true } });
/* 28 */       con.addShape(new boolean[][] { { false, false, true }, { true, true, true } });
/* 29 */       con.addShape(new boolean[][] { { false, true }, { true, true, true } });
/* 30 */       con.addShape(new boolean[][] { { true, true }, { false, true, true } });
/* 31 */       con.addShape(new boolean[][] { { false, true, true }, { true, true } });
/* 32 */       frame = new TetrisFrame(con);
/*    */       
/* 34 */       logger = new LogGenerator();
/* 35 */       aiServer = new AIConnection();
/* 36 */       aiServer.start();
/*    */       
/*    */ 
/* 39 */       while (run)
/*    */       {
/*    */         try
/*    */         {
/* 43 */           Thread.sleep(remote ? 'd' : 'ˮ');
/*    */         }
/*    */         catch (InterruptedException e) {
/* 46 */           e.printStackTrace();
/*    */         }
/* 48 */         if (doTick) {
/* 49 */           con.tick();
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 54 */       e.printStackTrace();
/*    */     }
/*    */     try
/*    */     {
/* 58 */       logger.close();
/*    */     } catch (IOException e) {
/* 60 */       e.printStackTrace();
/*    */     }
/* 62 */     System.exit(0);
/*    */   }
/*    */   
/* 65 */   private static Color[] colors = { Color.BLUE, Color.GREEN, Color.RED, Color.YELLOW, Color.CYAN };
/*    */   
/*    */   public static void update()
/*    */   {
/* 69 */     int[][] data = con.getFinishedGrid();
/* 70 */     for (int x = 0; x < data.length; x++)
/*    */     {
/* 72 */       for (int y = 0; y < data[x].length; y++)
/*    */       {
/* 74 */         if (data[x][y] == 0)
/*    */         {
/* 76 */           frame.grid[x][y] = null;
/*    */         }
/*    */         else
/*    */         {
/* 80 */           frame.grid[x][y] = colors[(data[x][y] - 1)];
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 85 */     frame.render();
/*    */   }
/*    */   
/*    */   public static void addScore(int score)
/*    */   {
/* 90 */     score += score;
/* 91 */     System.out.println(score);
/*    */   }
/*    */   
/*    */   public static enum Keys
/*    */   {
/* 96 */     UP,  DOWN,  LEFT,  RIGHT,  NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Tüp\Desktop\tetrs ai\TetrisJ v5.1.jar!\dragon\tetris\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */