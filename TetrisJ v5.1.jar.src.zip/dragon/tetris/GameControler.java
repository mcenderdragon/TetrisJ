/*     */ package dragon.tetris;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GameControler
/*     */ {
/*  13 */   public int xPos = 0; public int yPos = 0;
/*     */   
/*  15 */   private ArrayList<boolean[][]> blocks = new ArrayList();
/*     */   
/*     */ 
/*  18 */   private int type = 0;
/*     */   public final int screenW;
/*     */   public final int screenH;
/*     */   
/*     */   public GameControler(int weidth, int height, int maxtypes)
/*     */   {
/*  24 */     this.screenW = weidth;
/*  25 */     this.screenH = height;
/*  26 */     this.finishedGrid = new int[weidth][height];
/*  27 */     this.maxTypes = maxtypes;
/*     */   }
/*     */   
/*     */   public void addShape(boolean[][] shape)
/*     */   {
/*  32 */     this.blocks.add(shape);
/*     */   }
/*     */   
/*     */   public void shiftLeft()
/*     */   {
/*  37 */     if (this.type == 0) {
/*  38 */       return;
/*     */     }
/*  40 */     if (--this.xPos < 0)
/*     */     {
/*  42 */       this.xPos = 0;
/*     */     }
/*     */     
/*  45 */     if (isInsideBlocks())
/*     */     {
/*  47 */       this.xPos += 1;
/*     */     }
/*     */     
/*  50 */     Main.update();
/*     */   }
/*     */   
/*     */   public void shiftRight()
/*     */   {
/*  55 */     if (this.type == 0) {
/*  56 */       return;
/*     */     }
/*  58 */     int m = ++this.xPos + this.aktiveBlock.length;
/*  59 */     if (m > this.screenW)
/*     */     {
/*  61 */       this.xPos = (this.screenW - this.aktiveBlock.length);
/*     */     }
/*     */     
/*  64 */     if (isInsideBlocks())
/*     */     {
/*  66 */       this.xPos -= 1;
/*     */     }
/*     */     
/*  69 */     Main.update();
/*     */   }
/*     */   
/*     */   public void rotate()
/*     */   {
/*  74 */     if (this.type == 0) {
/*  75 */       return;
/*     */     }
/*  77 */     this.aktiveBlock = rotateAround(this.aktiveBlock.length, this.aktiveBlock[0].length, this.aktiveBlock);
/*     */     
/*  79 */     while (this.xPos + this.aktiveBlock.length > this.screenW)
/*     */     {
/*  81 */       this.xPos -= 1;
/*     */     }
/*     */     
/*  84 */     Main.update();
/*     */   }
/*     */   
/*     */   public final int maxTypes;
/*     */   private boolean[][] aktiveBlock;
/*     */   private int[][] finishedGrid;
/*     */   public boolean putDown()
/*     */   {
/*  92 */     if (this.type == 0) {
/*  93 */       return false;
/*     */     }
/*  95 */     this.yPos += 1;
/*     */     
/*  97 */     for (int x = 0; x < this.aktiveBlock.length; x++)
/*     */     {
/*  99 */       for (int y = 0; y < this.aktiveBlock[x].length; y++)
/*     */       {
/* 101 */         if (this.aktiveBlock[x][y] != 0)
/*     */         {
/*     */ 
/* 104 */           int w = x + this.xPos;
/* 105 */           int h = y + this.yPos;
/*     */           
/* 107 */           if (h >= this.finishedGrid[w].length)
/*     */           {
/* 109 */             this.yPos -= 1;
/* 110 */             return false;
/*     */           }
/*     */           
/* 113 */           if (this.finishedGrid[w][h] != 0)
/*     */           {
/* 115 */             this.yPos -= 1;
/* 116 */             return false;
/*     */           }
/*     */         } }
/*     */     }
/* 120 */     Main.update();
/* 121 */     return true;
/*     */   }
/*     */   
/*     */   public void tick()
/*     */   {
/* 126 */     Main.logger.onKeyPressed(Main.Keys.NONE);
/*     */     
/* 128 */     if (this.type == 0)
/*     */     {
/* 130 */       initNewShape();
/* 131 */       this.xPos = (this.screenW / 2);
/* 132 */       this.yPos = 0;
/*     */       
/* 134 */       if (isInsideBlocks())
/*     */       {
/* 136 */         throw new IllegalStateException("Game Over!");
/*     */       }
/*     */       
/* 139 */       Main.addScore(1);
/* 140 */       return;
/*     */     }
/*     */     
/* 143 */     if (!putDown())
/*     */     {
/* 145 */       for (int x = 0; x < this.aktiveBlock.length; x++)
/*     */       {
/* 147 */         for (int y = 0; y < this.aktiveBlock[x].length; y++)
/*     */         {
/* 149 */           if (this.aktiveBlock[x][y] != 0)
/*     */           {
/* 151 */             int w = x + this.xPos;
/* 152 */             int h = y + this.yPos;
/* 153 */             this.finishedGrid[w][h] = this.type;
/*     */           }
/*     */         }
/*     */       }
/* 157 */       Main.logger.shapeCollided(this.xPos, this.yPos);
/*     */       
/* 159 */       this.aktiveBlock = null;
/* 160 */       this.type = 0;
/*     */     }
/*     */     
/* 163 */     applyGravity();
/* 164 */     removeFullLines();
/*     */     
/* 166 */     Main.update();
/*     */   }
/*     */   
/*     */   public void initNewShape()
/*     */   {
/* 171 */     int rand = this.blocks.size();
/* 172 */     rand = (int)(System.currentTimeMillis() % rand);
/* 173 */     this.aktiveBlock = ((boolean[][])this.blocks.get(rand));
/* 174 */     this.type = (1 + (int)(System.currentTimeMillis() % this.maxTypes));
/* 175 */     int rot = (int)(System.currentTimeMillis() % 4L);
/* 176 */     for (int i = 0; i < rot; i++)
/*     */     {
/* 178 */       this.aktiveBlock = rotateAround(this.aktiveBlock.length, this.aktiveBlock[0].length, this.aktiveBlock);
/*     */     }
/* 180 */     Main.logger.onNewShape(this.finishedGrid, this.aktiveBlock);
/* 181 */     Main.aiServer.blockUpdate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeFullLines()
/*     */   {
/* 189 */     for (int y = 0; y < this.screenH; y++)
/*     */     {
/* 191 */       boolean full = true;
/* 192 */       for (int x = 0; x < this.screenW; x++)
/*     */       {
/* 194 */         if (this.finishedGrid[x][y] == 0)
/*     */         {
/* 196 */           full = false;
/* 197 */           break;
/*     */         }
/*     */       }
/*     */       
/* 201 */       if (full)
/*     */       {
/* 203 */         for (int x = 0; x < this.screenW; x++)
/*     */         {
/* 205 */           this.finishedGrid[x][y] = 0;
/*     */         }
/* 207 */         Main.addScore(100);
/* 208 */         Main.logger.onRemoveLine();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void applyGravity()
/*     */   {
/* 218 */     for (int y = this.screenH - 1; y >= 0; y--)
/*     */     {
/* 220 */       boolean lineEmpty = true;
/* 221 */       for (int x = 0; x < this.screenW; x++)
/*     */       {
/* 223 */         if (this.finishedGrid[x][y] != 0)
/*     */         {
/* 225 */           lineEmpty = false;
/* 226 */           break;
/*     */         }
/*     */       }
/*     */       
/* 230 */       if ((lineEmpty) && (y > 0))
/*     */       {
/* 232 */         for (int x = 0; x < this.screenW; x++)
/*     */         {
/* 234 */           this.finishedGrid[x][y] = this.finishedGrid[x][(y - 1)];
/* 235 */           this.finishedGrid[x][(y - 1)] = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isInsideBlocks()
/*     */   {
/* 243 */     for (int x = 0; x < this.aktiveBlock.length; x++)
/*     */     {
/* 245 */       for (int y = 0; y < this.aktiveBlock[x].length; y++)
/*     */       {
/* 247 */         if (this.aktiveBlock[x][y] != 0)
/*     */         {
/*     */ 
/* 250 */           int w = x + this.xPos;
/* 251 */           int h = y + this.yPos;
/*     */           
/*     */ 
/* 254 */           if (this.finishedGrid[w][h] != 0)
/*     */           {
/* 256 */             return true; }
/*     */         }
/*     */       }
/*     */     }
/* 260 */     return false;
/*     */   }
/*     */   
/*     */   public int[][] getFinishedGrid()
/*     */   {
/* 265 */     int[][] done = new int[this.screenW][this.screenH];
/* 266 */     for (int x = 0; x < done.length; x++)
/*     */     {
/* 268 */       done[x] = Arrays.copyOf(this.finishedGrid[x], this.screenH);
/*     */     }
/*     */     
/* 271 */     if (this.type != 0)
/*     */     {
/* 273 */       for (int x = 0; x < this.aktiveBlock.length; x++)
/*     */       {
/* 275 */         for (int y = 0; y < this.aktiveBlock[x].length; y++)
/*     */         {
/* 277 */           if (this.aktiveBlock[x][y] != 0)
/*     */           {
/* 279 */             int w = x + this.xPos;
/* 280 */             int h = y + this.yPos;
/* 281 */             done[w][h] = this.type;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 287 */     return done;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean[][] rotateAround(int w, int h, boolean[][] shape)
/*     */   {
/* 293 */     boolean[][] rotated = new boolean[h][w];
/*     */     
/* 295 */     for (int x = 0; x < w; x++)
/*     */     {
/* 297 */       for (int y = 0; y < h; y++)
/*     */       {
/* 299 */         boolean base = shape[x][y];
/* 300 */         rotated[(h - y - 1)][x] = base;
/*     */       }
/*     */     }
/*     */     
/* 304 */     return rotated;
/*     */   }
/*     */ }


/* Location:              C:\Users\Tüp\Desktop\tetrs ai\TetrisJ v5.1.jar!\dragon\tetris\GameControler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */